"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useBusyToast } from "@/hooks/useBusyToast";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const params = useSearchParams();
  const urlError = params.get("error") || undefined;
  const next = params.get("next") || undefined;

  const { promise } = useBusyToast();

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setSubmitting(true);
    setErrorMsg(null);

    try {
      // Build a safe redirect URL for the callback
      const origin =
        typeof window !== "undefined"
          ? window.location.origin
          : process.env.NEXT_PUBLIC_SITE_URL;

      const qs = new URLSearchParams();
      if (next && next.startsWith("/")) qs.set("next", next);
      const redirectTo = `${origin}/auth/callback${
        qs.toString() ? `?${qs.toString()}` : ""
      }`;

      const req = supabase.auth.signInWithOtp({
        email,
        options: {
          emailRedirectTo: redirectTo,
          // shouldCreateUser: true (default) — leave as-is unless you want to block non-existing users
        },
      });

      // Block UI + show toast lifecycle
      await promise(req, {
        loading: "Sending magic link…",
        success: "Magic link sent! Check your email",
        error: "Failed to send magic link",
      });

      // Only show the success panel AFTER the busy toast resolves successfully
      setSent(true);
    } catch (err) {
      console.error("[login] signInWithOtp error:", err);
      // Only show the error panel AFTER the busy toast resolves with error
      setErrorMsg(
        "We couldn&apos;t send the magic link. Please verify the email and try again."
      );
      setSent(false);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-linear-to-br from-zinc-950 via-zinc-900 to-black py-10 px-4 flex items-center justify-center">
      <div className="mx-auto max-w-xl w-full">
        <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-card/95 backdrop-blur-xl shadow-2xl">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-linear-to-br from-white/5 via-transparent to-transparent pointer-events-none" />
          <div className="absolute inset-0 bg-linear-to-tr from-transparent via-blue-500/5 to-purple-500/5 pointer-events-none" />

          {/* Header */}
          <div className="relative border-b border-white/10 bg-linear-to-r from-white/10 via-white/5 to-transparent px-8 py-8">
            <h1 className="text-3xl font-bold text-white mb-2">Sign in</h1>
            <p className="text-white/60 text-sm">
              We&apos;ll email you a secure magic link to sign in
            </p>
          </div>

          {/* Body */}
          <div className="relative p-8 space-y-6">
            {/* URL error (e.g., unauthorized on return) */}
            {urlError && (
              <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 backdrop-blur-sm p-4 text-sm text-rose-300">
                Couldn&apos;t complete sign-in (<strong>{urlError}</strong>).
                Please try again.
              </div>
            )}

            {/* Show ONLY after busy toast resolves with error */}
            {errorMsg && (
              <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 backdrop-blur-sm p-4">
                <h2 className="text-rose-300 font-semibold text-base">
                  Something went wrong
                </h2>
                <p className="text-sm text-rose-300/80 mt-1">{errorMsg}</p>
              </div>
            )}

            {/* Show ONLY after busy toast resolves with success */}
            {sent ? (
              <div className="text-center">
                <div className="rounded-3xl border border-emerald-500/30 bg-emerald-500/10 backdrop-blur-sm p-8 mb-6">
                  <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/30">
                    <svg
                      className="w-8 h-8 text-emerald-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                      />
                    </svg>
                  </div>
                  <h2 className="text-xl font-semibold text-white mb-2">
                    Check your email
                  </h2>
                  <p className="text-white/70 text-sm">
                    We sent a magic sign-in link to{" "}
                    <strong className="text-white">{email}</strong>. Open it on
                    this device to finish signing in.
                  </p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  className="border-white/20 bg-white/5 text-white hover:bg-white/10"
                  onClick={() => {
                    setSent(false);
                    setErrorMsg(null);
                  }}
                >
                  Use a different email
                </Button>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label
                    htmlFor="email"
                    className="text-sm font-medium text-white/80"
                  >
                    Email *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@school.edu"
                    className="bg-white/5 border-white/20 text-white placeholder:text-white/40 focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={submitting || !email}
                  className="w-full bg-linear-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white py-3 px-6 rounded-xl font-semibold text-base transition-all duration-200 shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting ? (
                    <span className="flex items-center justify-center">
                      <svg
                        className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        />
                      </svg>
                      Sending link…
                    </span>
                  ) : (
                    "Send magic link"
                  )}
                </Button>

                <p className="text-xs text-white/50 text-center">
                  You&apos;ll be redirected back here automatically after
                  clicking the link.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
