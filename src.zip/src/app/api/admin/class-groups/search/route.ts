/* eslint-disable @typescript-eslint/no-explicit-any */
// GET /api/admin/class-groups/search
import { NextRequest } from "next/server";
import { requireSchoolAdmin } from "@/lib/auth/requireSchoolAdmin";
import { connectToDatabase } from "@/db/connectToDatabase";
import { ClassGroup } from "@/models/ClassGroup";
import { Grade } from "@/models/Grade";
import mongoose from "mongoose";

export async function GET(req: NextRequest) {
  try {
    const { schoolId } = await requireSchoolAdmin();
    await connectToDatabase();

    const url = new URL(req.url);
    const activeOnly = url.searchParams.get("active") === "1";
    const search = url.searchParams.get("search")?.trim() || "";

    const query: any = { schoolId };
    if (activeOnly) {
      query.isActive = true;
    }

    // Build search query
    if (search) {
      query.name = { $regex: search, $options: "i" };
    }

    const classGroups = await ClassGroup.find(query)
      .sort({ name: 1 })
      .limit(50)
      .lean();

    // Fetch grade names for each class group
    const gradeIds = [
      ...new Set(
        classGroups
          .map((cg: any) => cg.gradeId)
          .filter((id: any) => id)
          .map((id: any) => String(id))
      ),
    ];

    const grades =
      gradeIds.length > 0
        ? await Grade.find({
            _id: { $in: gradeIds.map((id) => new mongoose.Types.ObjectId(id)) },
          })
            .select("_id name")
            .lean()
        : [];

    const gradeMap = new Map(
      grades.map((g: any) => [String(g._id), g.name])
    );

    // Enrich class groups with grade names
    const enriched = classGroups.map((cg: any) => ({
      _id: String(cg._id),
      name: cg.name,
      gradeId: cg.gradeId ? String(cg.gradeId) : undefined,
      gradeName: cg.gradeId ? gradeMap.get(String(cg.gradeId)) : undefined,
    }));

    return Response.json(enriched, { status: 200 });
  } catch (error: unknown) {
    console.error(error);
    const message =
      error instanceof Error ? error.message : "Failed to search class groups";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
