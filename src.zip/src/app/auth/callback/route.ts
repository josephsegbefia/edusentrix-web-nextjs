/* eslint-disable @typescript-eslint/no-explicit-any */
// // src/app/auth/callback/route.ts
// export const runtime = "nodejs";
// export const dynamic = "force-dynamic";

// import { NextRequest, NextResponse } from "next/server";
// import { supabaseServer } from "@/lib/supabase/server";
// import { connectToDatabase } from "@/db/connectToDatabase";
// import { User } from "@/models/User";

// /**
//  * Small app-facing shape for decision logic
//  */
// type AppUserLean = {
//   role?:
//     | "platform_admin"
//     | "platformAdmin"
//     | "school_admin"
//     | "schoolAdmin"
//     | "staff"
//     | "teacher"
//     | "parent"
//     | "student";
//   pendingOnboarding?: boolean;
//   schoolId?: string | null;
// };

// /**
//  * Only honor safe, relative next params.
//  */
// function sanitizeNextParam(url: URL) {
//   const next = url.searchParams.get("next");
//   if (!next) return null;
//   if (!next.startsWith("/")) return null; // no absolute/externals
//   return next;
// }

// /**
//  * Centralized decision for where to send the user next.
//  * NEW: first-time school_admins (pendingOnboarding=true) go to /onboarding.
//  */
// function decideNextPath(u: AppUserLean) {
//   if (
//     (u.role === "school_admin" || u.role === "schoolAdmin") &&
//     u.pendingOnboarding
//   ) {
//     return "/onboarding"; // kickoff page (button -> /onboard wizard)
//   }

//   switch (u.role) {
//     case "platform_admin":
//     case "platformAdmin":
//       return "/platform";
//     case "school_admin":
//     case "schoolAdmin":
//       return "/admin";
//     case "teacher":
//       return "/teacher";
//     case "parent":
//       return "/parent";
//     case "student":
//       return "/student";
//     default:
//       return "/dashboard"; // safe fallback
//   }
// }

// export async function GET(req: NextRequest) {
//   const url = new URL(req.url);
//   const code = url.searchParams.get("code");

//   // For PKCE magic links we must receive ?code=
//   if (!code) {
//     return NextResponse.redirect(new URL("/login?error=missing_code", url));
//   }

//   // 1) Exchange code for a session (sets Supabase cookies)
//   const supabase = await supabaseServer();
//   const { error: exchErr } = await supabase.auth.exchangeCodeForSession(code);
//   if (exchErr) {
//     // Typically invalid/expired link
//     return NextResponse.redirect(new URL("/login?error=auth", url));
//   }

//   // 2) Get the Supabase user
//   const { data: auth } = await supabase.auth.getUser();
//   if (!auth?.user) {
//     return NextResponse.redirect(new URL("/login?error=unauthorized", url));
//   }

//   // 3) Load App user (Mongo) and shape minimal data
//   await connectToDatabase();
//   let doc = await User.findOne({ supabaseUserId: auth.user.id })
//     .select("role pendingOnboarding schoolId email firstName lastName")
//     .lean<{
//       role?: AppUserLean["role"];
//       pendingOnboarding?: boolean;
//       schoolId?: unknown;
//       email?: string;
//       firstName?: string;
//       lastName?: string;
//     }>();

//   // If user doesn't exist in MongoDB, create them (shouldn't happen for approved apps, but handle it)
//   if (!doc) {
//     // Try to get role from Supabase metadata
//     const roleFromMetadata = auth.user.user_metadata?.role;
//     const defaultRole = roleFromMetadata || "school_admin";

//     const newUser = await User.create({
//       supabaseUserId: auth.user.id,
//       email: auth.user.email?.toLowerCase() || "",
//       firstName:
//         auth.user.user_metadata?.firstName ||
//         auth.user.user_metadata?.full_name?.split(" ")[0],
//       lastName:
//         auth.user.user_metadata?.lastName ||
//         auth.user.user_metadata?.full_name?.split(" ").slice(1).join(" "),
//       role: defaultRole,
//       pendingOnboarding: true,
//     });
//     doc = {
//       role: newUser.role as AppUserLean["role"],
//       pendingOnboarding: !!newUser.pendingOnboarding,
//       schoolId: newUser.schoolId,
//       email: newUser.email,
//       firstName: newUser.firstName,
//       lastName: newUser.lastName,
//     };
//   } else {
//     // Sync role to Supabase if it's different
//     const roleInSupabase = auth.user.user_metadata?.role;
//     if (doc.role && doc.role !== roleInSupabase) {
//       const { supabaseAdmin } = await import("@/lib/supabase/admin");
//       await supabaseAdmin.auth.admin.updateUserById(auth.user.id, {
//         user_metadata: { role: doc.role },
//       });
//     }
//   }

//   const appUser: AppUserLean = {
//     role: doc?.role,
//     pendingOnboarding: !!doc?.pendingOnboarding,
//     schoolId: doc?.schoolId ? String(doc.schoolId) : null,
//   };

//   // 4) Optional `?next=` override if provided and safe
//   const safeNext = sanitizeNextParam(url);
//   const destination = safeNext || decideNextPath(appUser);

//   return NextResponse.redirect(new URL(destination, url));
// }

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabase/server";
import { connectToDatabase } from "@/db/connectToDatabase";
import { User } from "@/models/User";

/** Centralized routing after login */
function decideNextPath(appUser: {
  role?: string;
  pendingOnboarding?: boolean;
  schoolId?: string | null;
}) {
  // Your “soft landing” idea:
  if (appUser.role === "school_admin" && appUser.pendingOnboarding) {
    return "/onboarding"; // a simple page with “Start school onboarding”
  }

  switch (appUser.role) {
    case "platform_admin":
    case "platformAdmin":
      return "/platform";
    case "school_admin":
    case "schoolAdmin":
      return "/admin";
    case "teacher":
      return "/teacher";
    case "parent":
      return "/parent";
    case "student":
      return "/student";
    default:
      return "/dashboard";
  }
}

/** Only allow safe internal next params */
function sanitizeNextParam(url: URL) {
  const n = url.searchParams.get("next");
  if (!n) return null;
  if (!n.startsWith("/")) return null;
  return n;
}

export async function GET(req: NextRequest) {
  const url = new URL(req.url);

  // Supabase can return either "code" (PKCE) or "token_hash"+"type" (admin magiclink/recovery/invite)
  const code = url.searchParams.get("code");
  const tokenHash = url.searchParams.get("token_hash");
  const otpType = url.searchParams.get("type"); // e.g. "magiclink", "recovery", "signup", etc.
  const email = url.searchParams.get("email") || undefined; // sometimes present on links

  const supabase = await supabaseServer();

  // 1) Establish a session
  try {
    if (code) {
      // Flow: PKCE from signInWithOtp (login page)
      const { error } = await supabase.auth.exchangeCodeForSession(code);
      if (error) {
        return NextResponse.redirect(new URL("/login?error=auth", url));
      }
    } else if (tokenHash && otpType) {
      // Flow: server-generated links via admin.generateLink
      // Some link types require email; pass it if present (safe).
      const { error } = await supabase.auth.verifyOtp({
        type: otpType as any, // "magiclink" | "recovery" | "signup" etc.
        token_hash: tokenHash,
        ...(email ? { email } : {}),
      } as any);
      if (error) {
        return NextResponse.redirect(new URL("/login?error=auth", url));
      }
    } else {
      // Neither flow present
      return NextResponse.redirect(new URL("/login?error=missing_token", url));
    }
  } catch {
    return NextResponse.redirect(new URL("/login?error=auth", url));
  }

  // 2) We should now have a Supabase session cookie.
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) {
    return NextResponse.redirect(new URL("/login?error=unauthorized", url));
  }

  // 3) Load/repair our App user record
  await connectToDatabase();

  // Try to find a user by supabaseUserId first
  let doc = await User.findOne({ supabaseUserId: auth.user.id })
    .select("role pendingOnboarding schoolId supabaseUserId email")
    .lean();

  // If not found, try by email (covers temp supabase ids set during approval)
  if (!doc && auth.user.email) {
    const byEmailRaw = await User.findOne({
      email: auth.user.email.toLowerCase(),
    })
      .select("role pendingOnboarding schoolId supabaseUserId email")
      .lean();

    // findOne returns a single document or null, but TypeScript infers it could be an array
    const byEmail = Array.isArray(byEmailRaw) ? null : byEmailRaw;

    if (byEmail) {
      // If the stored supabaseUserId looks temporary, fix it now
      if (
        !byEmail.supabaseUserId ||
        byEmail.supabaseUserId.startsWith("temp_")
      ) {
        await User.updateOne(
          { _id: byEmail._id },
          { $set: { supabaseUserId: auth.user.id } }
        );
      }
      doc = {
        ...byEmail,
        supabaseUserId: auth.user.id,
      } as typeof byEmail;
    }
  }

  // If still not found, you can choose to soft-create, or bounce to login with error.
  if (!doc) {
    // Soft-create as an unscoped user if you prefer:
    // await User.create({ supabaseUserId: auth.user.id, email: auth.user.email || "" });
    // For now, redirect with an error so we notice mismatches.
    return NextResponse.redirect(new URL("/login?error=user_not_found", url));
  }

  const appUser = {
    role: (doc as any).role as string | undefined,
    pendingOnboarding: !!(doc as any).pendingOnboarding,
    schoolId: (doc as any).schoolId ? String((doc as any).schoolId) : null,
  };

  // 4) Optional `?next=` override (internal only)
  const safeNext = sanitizeNextParam(url);
  const dest = safeNext || decideNextPath(appUser);

  return NextResponse.redirect(new URL(dest, url));
}
