/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextRequest, NextResponse } from "next/server";
import mongoose from "mongoose";
import { z } from "zod";
import { connectToDatabase } from "@/db/connectToDatabase";
import { requirePlatformAdmin } from "@/lib/auth/requirePlatformAdmin";
import { Application } from "@/models/Application";
import { School } from "@/models/School";
import { User } from "@/models/User";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { sendEmail } from "@/lib/email/brevo";
import { recordApplicationAudit } from "@/lib/audit/recordApplicationAudit";

const BodySchema = z.object({ note: z.string().optional() });

export async function POST(
  req: NextRequest,
  ctx: { params: Promise<{ id: string }> }
) {
  const guard = await requirePlatformAdmin();
  if (!guard.ok) return guard.res;
  const platformAdminId = guard.me!._id;

  const parsed = BodySchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success)
    return NextResponse.json({ error: "Invalid body" }, { status: 400 });

  await connectToDatabase();
  const session = await mongoose.connection.startSession();
  const { id } = await ctx.params;

  try {
    let schoolIdCreated: mongoose.Types.ObjectId | null = null;
    let adminEmail = "";
    let adminFullName = "";
    let schoolNameForEmail = "";

    await session.withTransaction(async () => {
      const app = await Application.findById(id).session(session);
      if (!app) throw new Error("Application not found");

      if (!["submitted", "reviewed"].includes(app.status)) {
        if (app.status === "approved") return; // idempotent success
        throw new Error(
          `Invalid transition from '${app.status}' to 'approved'`
        );
      }

      adminEmail = app.adminEmail.toLowerCase();
      adminFullName = `${app.adminFirstName} ${app.adminLastName}`.trim();
      schoolNameForEmail = app.schoolName;

      // 1) Create or reuse School (pending; onboarding will flip to active)
      let school: any;
      if (app.linkedSchoolId) {
        school = await School.findById(app.linkedSchoolId).session(session);
        if (!school) throw new Error("Linked school not found");
        school.status = "pending";
        await school.save({ session });
      } else {
        school = await School.create(
          [
            {
              name: app.schoolName,
              type: app.schoolType,
              address: (app as any).address || undefined,
              city: app.city || undefined,
              region: app.region || undefined,
              status: "pending",
              createdBy: platformAdminId,
            },
          ],
          { session }
        ).then(([doc]) => doc);
      }
      schoolIdCreated = school._id;

      // 2) Ensure local User (by email); supabaseUserId may be added later on first login/invite
      const existingUser = await User.findOne({ email: adminEmail })
        .session(session)
        .lean();

      if (existingUser) {
        await User.updateOne(
          { email: adminEmail },
          {
            $set: {
              name: adminFullName,
              phone: (app as any).adminPhone || null,
              role: "school_admin",
              schoolId: school._id,
              pendingOnboarding: true,
            },
          },
          { session }
        );
      } else {
        await User.create(
          [
            {
              email: adminEmail,
              name: adminFullName,
              phone: (app as any).adminPhone || null,
              role: "school_admin",
              schoolId: school._id,
              pendingOnboarding: true,
            },
          ],
          { session }
        );
      }

      // 3) Mark application approved + link school + processor
      app.status = "approved";
      app.linkedSchoolId = school._id as any;
      app.processedBy = platformAdminId as any;
      await app.save({ session });

      // 4) Audit
      await recordApplicationAudit(
        {
          applicationId: app._id,
          action: "approved",
          by: platformAdminId,
          note: parsed.data?.note,
          meta: { linkedSchoolId: String(school._id) },
        },
        { session }
      );
    });

    // 5) Send Admin Invite email (creates Supabase user + sends link to our callback)
    const APP_URL = process.env.APP_URL!;
    const redirectTo = `${APP_URL}/auth/callback?next=/get-started`;

    const { data: inviteData, error: inviteErr } =
      await supabaseAdmin.auth.admin.inviteUserByEmail(adminEmail, {
        redirectTo,
      });

    if (inviteErr) {
      // Fallback: generate a magic link to the same callback
      const { error: altErr } = await supabaseAdmin.auth.admin.generateLink({
        type: "magiclink",
        email: adminEmail,
        options: { redirectTo },
      } as any);
      if (altErr) {
        return NextResponse.json(
          {
            error: "Could not send invite/magic link",
            details: altErr.message,
          },
          { status: 500 }
        );
      }
      // No user id in this path
    } else if (inviteData?.user?.id) {
      // Sync Supabase user id onto our local User record
      await User.updateOne(
        { email: adminEmail },
        { $set: { supabaseUserId: inviteData.user.id } }
      );
    }

    // 6) Optional branded email (points to same flow)
    try {
      await sendEmail(adminEmail, "SCHOOL_INVITE", {
        schoolName: schoolNameForEmail,
        setupLink: redirectTo,
      });
    } catch {
      /* non-fatal */
    }

    return NextResponse.json({ success: true, schoolId: schoolIdCreated });
  } catch (e: any) {
    console.log("Approval failed", e);
    return NextResponse.json(
      { error: "Approval failed", details: e?.message || String(e) },
      { status: 500 }
    );
  } finally {
    session.endSession();
  }
}
